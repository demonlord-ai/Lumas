import os
from dotenv import load_dotenv
import uvicorn
from fastapi import FastAPI, Request, Response
from telegram import Update
from telegram.ext import CommandHandler

from .bot_instance import bot_application
from .plugin_manager import plugin_manager
from .core_commands import core_handlers

# Load environment variables from .env file
load_dotenv()

# Get environment variables
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
BASE_WEBHOOK_URL = os.getenv("BASE_WEBHOOK_URL")
if not TELEGRAM_BOT_TOKEN or not BASE_WEBHOOK_URL:
    raise ValueError("TELEGRAM_BOT_TOKEN and BASE_WEBHOOK_URL must be set in the .env file")

WEBHOOK_PATH = f"/webhook/{TELEGRAM_BOT_TOKEN}"
WEBHOOK_URL = f"{BASE_WEBHOOK_URL}{WEBHOOK_PATH}"

# --- FastAPI App ---
app = FastAPI()

# --- Telegram Bot Handlers (Core Commands) ---
async def start(update: Update, context) -> None:
    """Sends a message when the command /start is issued."""
    await update.message.reply_html(
        rf"Hi {update.effective_user.first_name}! I am Luma, your personal AI assistant."
    )

async def help_command(update: Update, context) -> None:
    """Sends a message when the command /help is issued."""
    await update.message.reply_text("Use /plugins to manage available features.")

async def handle_telegram_update(request: Request) -> Response:
    """Handles incoming Telegram updates via webhook."""
    json_update = await request.json()
    update = Update.de_json(json_update, bot_application.bot)
    await bot_application.process_update(update)
    return Response(status_code=200)

# --- App Lifecycle ---
async def on_startup():
    """Sets up the bot, plugins, and webhook on application startup."""
    # Register core handlers that should always be active
    bot_application.add_handler(CommandHandler("start", start))
    bot_application.add_handler(CommandHandler("help", help_command))
    for handler in core_handlers:
        bot_application.add_handler(handler)

    # Discover plugins so they are ready to be managed via the /plugins command
    plugin_manager.discover_plugins()

    # Set the webhook
    await bot_application.bot.set_webhook(url=WEBHOOK_URL)
    print(f"Webhook set to {WEBHOOK_URL}")

async def on_shutdown():
    """Cleans up by deleting the webhook on application shutdown."""
    print("Deleting webhook...")
    await bot_application.bot.delete_webhook()
    print("Webhook deleted.")

# Add lifecycle events to FastAPI app
app.add_event_handler("startup", on_startup)
app.add_event_handler("shutdown", on_shutdown)

# Define the webhook endpoint
app.add_api_route(
    path=WEBHOOK_PATH,
    endpoint=handle_telegram_update,
    methods=["POST"],
)

if __name__ == "__main__":
    print("Starting Uvicorn server for local development...")
    uvicorn.run("src.main:app", host="0.0.0.0", port=8000, reload=True)