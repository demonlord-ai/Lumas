import importlib
import os
from typing import Dict, List
from telegram.ext import BaseHandler
from .bot_instance import bot_application

class PluginManager:
    def __init__(self, plugin_dir: str = "src/plugins"):
        self.plugin_dir = plugin_dir
        # {plugin_name: {module: module, handlers: [...]}}
        self.plugins: Dict[str, dict] = {}
        # {plugin_name: is_active_bool}
        self.active_plugins: Dict[str, bool] = {}

    def discover_plugins(self):
        """Discovers plugins in the plugin directory and populates the plugin list."""
        self.plugins.clear() # Clear existing list before re-discovering
        for plugin_name in os.listdir(self.plugin_dir):
            plugin_path = os.path.join(self.plugin_dir, plugin_name)
            # A plugin is a directory that doesn't start with an underscore
            if os.path.isdir(plugin_path) and not plugin_name.startswith("__"):
                self.plugins[plugin_name] = {"module": None, "handlers": []}
                # Ensure every discovered plugin has a default inactive state
                if plugin_name not in self.active_plugins:
                    self.active_plugins[plugin_name] = False
        print(f"Discovered plugins: {list(self.plugins.keys())}")

    def load_plugin(self, plugin_name: str) -> bool:
        """Loads a specific plugin, imports its module, and registers its handlers."""
        if plugin_name not in self.plugins:
            print(f"Error: Plugin '{plugin_name}' not found.")
            return False

        try:
            # Dynamically import the plugin's main file (e.g., src.plugins.echo.plugin)
            module_path = f"src.plugins.{plugin_name}.plugin"
            # If the module was already imported, reload it to get fresh code
            if self.plugins[plugin_name].get("module"):
                plugin_module = importlib.reload(self.plugins[plugin_name]["module"])
            else:
                plugin_module = importlib.import_module(module_path)

            self.plugins[plugin_name]["module"] = plugin_module

            # The plugin module must have a 'get_handlers' function
            if hasattr(plugin_module, "get_handlers"):
                handlers: List[BaseHandler] = plugin_module.get_handlers()
                self.plugins[plugin_name]["handlers"] = handlers
                for handler in handlers:
                    bot_application.add_handler(handler)

                self.active_plugins[plugin_name] = True
                print(f"Plugin '{plugin_name}' loaded successfully with {len(handlers)} handlers.")
                return True
            else:
                print(f"Error: Plugin '{plugin_name}' is missing the 'get_handlers' function.")
                return False
        except ImportError as e:
            print(f"Error loading plugin '{plugin_name}': {e}")
            return False

    def unload_plugin(self, plugin_name: str) -> bool:
        """Unloads a specific plugin and removes its handlers from the bot."""
        if plugin_name not in self.plugins or not self.active_plugins.get(plugin_name):
            print(f"Error: Plugin '{plugin_name}' is not active or not found.")
            return False

        handlers_to_remove = self.plugins[plugin_name].get("handlers", [])
        for handler in handlers_to_remove:
            bot_application.remove_handler(handler)

        self.plugins[plugin_name]["handlers"] = []
        self.active_plugins[plugin_name] = False
        print(f"Plugin '{plugin_name}' unloaded successfully.")
        return True

# Create a single, shared instance of the PluginManager
plugin_manager = PluginManager()