from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CommandHandler, CallbackQueryHandler, ContextTypes
from .plugin_manager import plugin_manager

# --- Helper Functions ---

async def get_plugins_keyboard() -> InlineKeyboardMarkup:
    """Generates an inline keyboard with all plugins and their states."""
    keyboard = []
    # Ensure plugins are discovered before generating the keyboard
    if not plugin_manager.plugins:
        plugin_manager.discover_plugins()

    for name in plugin_manager.plugins:
        is_active = plugin_manager.active_plugins.get(name, False)
        status_emoji = "✅" if is_active else "❌"
        button_text = f"{name.capitalize()} {status_emoji}"
        callback_data = f"toggle_plugin:{name}"
        keyboard.append([InlineKeyboardButton(button_text, callback_data=callback_data)])

    return InlineKeyboardMarkup(keyboard)

# --- Command Handlers ---

async def plugins_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Displays the plugin management interface."""
    # TODO: Add owner-only check here in the future

    keyboard = await get_plugins_keyboard()
    await update.message.reply_text("Manage Plugins:", reply_markup=keyboard)


# --- Callback Query Handlers ---

async def plugin_toggle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handles the button presses for toggling plugins."""
    query = update.callback_query
    await query.answer() # Acknowledge the button press

    # Data is in the format "toggle_plugin:plugin_name"
    action, plugin_name = query.data.split(":")

    if action == "toggle_plugin":
        is_active = plugin_manager.active_plugins.get(plugin_name, False)

        message_text = ""
        if is_active:
            success = plugin_manager.unload_plugin(plugin_name)
            message_text = f"Plugin '{plugin_name}' has been disabled." if success else f"Failed to disable plugin '{plugin_name}'."
        else:
            success = plugin_manager.load_plugin(plugin_name)
            message_text = f"Plugin '{plugin_name}' has been enabled." if success else f"Failed to enable plugin '{plugin_name}'."

        # Update the keyboard to show the new state and edit the message in one call
        new_keyboard = await get_plugins_keyboard()
        await query.edit_message_text(
            text=message_text,
            reply_markup=new_keyboard
        )

# --- Public Handlers List ---

# A list of all handlers that should be registered by the main application
core_handlers = [
    CommandHandler("plugins", plugins_command),
    CallbackQueryHandler(plugin_toggle_callback, pattern="^toggle_plugin:")
]