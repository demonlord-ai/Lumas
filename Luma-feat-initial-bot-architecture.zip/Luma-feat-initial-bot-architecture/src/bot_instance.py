import os
from dotenv import load_dotenv
from telegram.ext import Application

# Load environment variables from .env file
load_dotenv()

# Get environment variables
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not TELEGRAM_BOT_TOKEN:
    raise ValueError("TELEGRAM_BOT_TOKEN must be set in the .env file")

# Create the bot application instance
bot_application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()