from telegram import Update
from telegram.ext import MessageHandler, filters, ContextTypes, BaseHandler
from typing import List

# --- Plugin Logic ---

async def echo_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Echo the user's message."""
    if update.message and update.message.text:
        await update.message.reply_text(update.message.text)

# --- Public API for Plugin Manager ---

def get_handlers() -> List[BaseHandler]:
    """
    Returns a list of handlers that this plugin provides.
    This function is called by the plugin manager to register the plugin's functionality.
    """
    # We are interested in text messages that are not commands.
    echo_handler = MessageHandler(filters.TEXT & ~filters.COMMAND, echo_message)
    return [echo_handler]